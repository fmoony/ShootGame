import unreal,json,pathlib,time,math,traceback
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/Smoothing03Compare_20261122_01");base='/Game/Experiments/Stance_20261022'
D={'handle':None,'rows':[],'case':0,'last':-1,'wall_start':time.monotonic()};unreal._torso_eight=D
names=[('F',0),('FR',45),('R',90),('BR',135),('B',180),('BL',-135),('L',-90),('FL',-45)]
cases=[{'name':'steady_'+n,'kind':'steady','from':y,'to':y,'duration':2.1,'delay':0.} for n,y in names]
for sign in [1,-1]:
 for i,(n,y) in enumerate(names):
  nn,yy=names[(i+sign)%8];cases.append({'name':n+'_'+nn,'kind':'adjacent','from':y,'to':yy,'duration':.8,'delay':0.})
for rep,delay in enumerate([0.,.33,.66]):
 for n,a,b in [('F_B',0,180),('B_F',180,0),('R_L',90,-90),('L_R',-90,90)]:cases.append({'name':n+'_repeat'+str(rep),'kind':'reverse','from':a,'to':b,'duration':.8,'delay':delay})
for sign in [1,-1]:cases.append({'name':'sweep_'+str(sign),'kind':'sweep','from':0,'to':0,'duration':5.,'sign':sign,'delay':0.})
cases=[c for c in cases if c['kind']=='steady']+[{'name':n+'_phase'+str(ph),'kind':'transition','from':a,'to':b,'duration':1.0,'delay':ph} for n,a,b in [('R_BR',90,135),('BR_R',135,90),('F_B',0,180),('B_F',180,0),('L_BL',-90,-135),('BL_L',-135,-90),('FL_L',-45,-90),('L_FL',-90,-45)] for ph in [0.,.25,.5,.75]];cases=[{'name':n+'_exact'+str(ph),'kind':'transition','from':a,'to':b,'duration':1.,'delay':0.,'desired_phase':ph} for n,a,b in [('R_BR',90,135),('F_B',0,180),('B_F',180,0)] for ph in [0.,.25,.5,.75]];D['cases']=cases;bones=['root','pelvis','spine_01','spine_02','spine_03','spine_04','spine_05','neck_01','neck_02','head','clavicle_l','clavicle_r','hand_l','hand_r','thigh_l','thigh_r','calf_l','calf_r','foot_l','foot_r','ball_l','ball_r']
def status(state,error=None):(O/'FocusStatus.json').write_text(json.dumps({'state':state,'case':D['case'],'total':len(cases),'frames':len(D['rows']),'error':error}),encoding='utf8')
def finish_pair(state,error=None):
 if D.get('handle') is not None:unreal.unregister_slate_post_tick_callback(D['handle']);D['handle']=None
 if 'secondary' in D:D['secondary'].destroy_actor();D.pop('secondary')
 if 'p' in D:
  for k,v in D['inputs'].items():D['p'].set_editor_property(k,v)
  D['p'].set_actor_tick_enabled(D['tick']);D['body'].set_editor_property('global_anim_rate_scale',D['rate']);D['settings'].set_editor_property('bThrottleCPUWhenNotForeground',D['throttle']);unreal.SystemLibrary.execute_console_command(D['p'],'t.MaxFPS '+str(D['fps']))
 (O/'FocusPair.json').write_text(json.dumps({'state':state,'error':error,'cases':cases,'rows':D['rows']},separators=(',',':')),encoding='utf8');status(state,error)
def pair_input(y):
 r=math.radians(y);f=math.cos(r);right=math.sin(r);m=abs(f)+abs(right)
 for p in [D['p'],D['secondary']]:p.set_editor_property('PreviewForward',f/m);p.set_editor_property('PreviewRight',right/m)
def next_pair(t):
 if D['case']>=len(cases):finish_pair('Complete');return
 pair_input(cases[D['case']]['from']);D['mode']='warm';D['time']=t;status('Running')
def record_pair(t):
 r={'case':D['case'],'t':t,'elapsed':t-D['time'],'poses':{}}
 for label,p,b in [('baseline',D['secondary'],D['secondary_body']),('trial',D['p'],D['body'])]:
  ai=b.get_anim_instance();rs={'class':ai.get_class().get_path_name(),'input':[p.get_editor_property('PreviewForward'),p.get_editor_property('PreviewRight')],'graph':[ai.get_editor_property('Forward'),ai.get_editor_property('Right')],'actor_z':p.get_actor_location().z,'body_z':b.get_world_location().z,'phase':ai.call_method('GetInstanceAssetPlayerTime',args=(0,)),'bones':{}}
  for n in bones:
   tr=b.get_socket_transform(n,unreal.RelativeTransformSpace.RTS_COMPONENT);rs['bones'][n]={'p':list(tr.translation.to_tuple()),'q':list(tr.rotation.to_tuple())}
  r['poses'][label]=rs
 r['phase_delta']=abs((r['poses']['baseline']['phase']-r['poses']['trial']['phase']+.5)%1.-.5);return r
def pair_tick(dt):
 try:
  t=unreal.GameplayStatics.get_time_seconds(D['world'])
  if D['last']==t:return
  D['last']=t;c=cases[D['case']]
  if D['mode']=='warm':
   if t-D['time']<1.3:return
   phase=D['body'].get_anim_instance().call_method('GetInstanceAssetPlayerTime',args=(0,))
   if (phase-c['desired_phase'])%1.>.018:return
   D['time']=t;D['mode']='run';D['rows'].append(record_pair(t));pair_input(c['to']);return
  D['rows'].append(record_pair(t));elapsed=t-D['time']
  if c['kind']=='sweep':pair_input(c['sign']*360.*min(1.,elapsed/c['duration']))
  if elapsed>=c['duration']:D['case']+=1;next_pair(t)
  if time.monotonic()-D['wall_start']>210:finish_pair('Timeout')
 except Exception:finish_pair('Failed',traceback.format_exc())
try:
 w=unreal.EditorLevelLibrary.get_game_world();p=unreal.GameplayStatics.get_player_pawn(w,0);b=p.get_editor_property('body');assert b.get_anim_instance().get_class().get_name()=='ABP_Smoothing03_Crouch_C',b.get_anim_instance().get_class().get_name()
 settings=unreal.load_object(None,'/Script/UnrealEd.Default__EditorPerformanceSettings');D.update(world=w,p=p,body=b,tick=p.is_actor_tick_enabled(),rate=b.get_editor_property('global_anim_rate_scale'),inputs={k:p.get_editor_property(k) for k in ['PreviewForward','PreviewRight']},settings=settings,throttle=settings.get_editor_property('bThrottleCPUWhenNotForeground'),fps=unreal.SystemLibrary.get_console_variable_float_value('t.MaxFPS'))
 (O/'FocusBefore.json').write_text(json.dumps({'world':w.get_path_name(),'anim':b.get_anim_instance().get_class().get_path_name(),'tick':D['tick'],'rate':D['rate'],'inputs':D['inputs'],'throttle':D['throttle'],'fps':D['fps'],'render':{k:unreal.SystemLibrary.get_console_variable_int_value(k) for k in ['r.MotionBlurQuality','r.AntiAliasingMethod']}},indent=2),encoding='utf8')
 settings.set_editor_property('bThrottleCPUWhenNotForeground',False);unreal.SystemLibrary.execute_console_command(p,'t.MaxFPS 60');p.set_actor_tick_enabled(False);b.set_editor_property('global_anim_rate_scale',1.)
 tr=p.get_actor_transform();tr.translation=unreal.Vector(0,400,0);lib=unreal.get_default_object(unreal.GameplayStatics);secondary=lib.call_method('BeginDeferredActorSpawnFromClass',args=(w,p.get_class(),tr,unreal.SpawnActorCollisionHandlingMethod.ALWAYS_SPAWN,None,unreal.SpawnActorScaleMethod.MULTIPLY_WITH_ROOT));D['secondary']=secondary;secondary=lib.call_method('FinishSpawningActor',args=(secondary,tr,unreal.SpawnActorScaleMethod.MULTIPLY_WITH_ROOT));D['secondary']=secondary;secondary.set_actor_tick_enabled(False);secondary.set_actor_hidden_in_game(True);b2=secondary.get_editor_property('body');D['secondary_body']=b2;b2.set_editor_property('visibility_based_anim_tick_option',unreal.VisibilityBasedAnimTickOption.ALWAYS_TICK_POSE_AND_REFRESH_BONES);b2.set_editor_property('global_anim_rate_scale',1.)
 b.set_anim_instance_class(None);b.set_anim_instance_class(unreal.load_asset(base+'/ABP_Smoothing03_Crouch').generated_class());b2.set_anim_instance_class(unreal.load_asset(base+'/ABP_TorsoReferenceEight_Crouch').generated_class());pc=unreal.GameplayStatics.get_player_controller(w,0);pc.set_view_target_with_blend(p,0.)
 D['mode']='warm';D['time']=unreal.GameplayStatics.get_time_seconds(w);pair_input(0);D['handle']=unreal.register_slate_post_tick_callback(pair_tick);status('Registered')
except Exception:finish_pair('SetupFailed',traceback.format_exc())
