import sys,json,pathlib,base64,time,subprocess
p=pathlib.Path(__file__).parent
sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent/'Tools/OrientationEvidence'))
from mcp import rpc
from PIL import Image
import io,imageio_ffmpeg
subprocess.run([sys.executable,'-B','-X','utf8',str(p/'run.py'),'video_preview.py'],check=True,capture_output=True)
def call(n,a):return json.loads(rpc('tools/call',{'name':'call_tool','arguments':{'toolset_name':'SlateInspectorToolset.SlateInspectorToolset','tool_name':n,'arguments':a}})['result']['content'][0]['text'])['returnValue']
frames=[];times=[];t0=time.monotonic()
while time.monotonic()-t0<9:
 x=call('Screenshot',{'ref':'w32'});im=Image.open(io.BytesIO(base64.b64decode(x['data']))).convert('RGB');im=im.resize((1280,688));frames.append(im);times.append(time.monotonic()-t0);time.sleep(.1)
frames[len(frames)//2].save(p/'ComparisonFrame.png')
frames[0].save(p/'Smoothing_AB.gif',save_all=True,append_images=frames[1:],duration=[int(1000*(b-a)) for a,b in zip(times,times[1:])]+[150],loop=0)
(p/'NativeCapture.json').write_text(json.dumps({'method':'Slate native Screenshot w32','times':times,'frames':len(frames),'note':'Illustrative recording; MCP screenshot calls may affect frame timing. Numerical metrics use separate captures.'},indent=2))
print('native_frames',len(frames),'duration',times[-1])
