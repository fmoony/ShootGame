import unreal,json,pathlib,traceback,math
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/Smoothing03Compare_20261122_01");base='/Game/Experiments/Stance_20261022';w=unreal.EditorLevelLibrary.get_game_world();p=unreal.GameplayStatics.get_player_pawn(w,0);b=p.get_editor_property('body');pc=unreal.GameplayStatics.get_player_controller(w,0);settings=unreal.load_object(None,'/Script/UnrealEd.Default__EditorPerformanceSettings')
V={'handle':None,'p':p,'b':b,'pc':pc,'world':w,'actors':[],'rows':[],'location':p.get_actor_location(),'rotation':p.get_actor_rotation(),'tick':p.is_actor_tick_enabled(),'rate':b.get_editor_property('global_anim_rate_scale'),'inputs':{n:p.get_editor_property(n) for n in ['PreviewForward','PreviewRight']},'throttle':settings.get_editor_property('bThrottleCPUWhenNotForeground'),'settings':settings,'fps':unreal.SystemLibrary.get_console_variable_float_value('t.MaxFPS'),'render':{k:unreal.SystemLibrary.get_console_variable_int_value(k) for k in ['r.MotionBlurQuality','r.AntiAliasingMethod']},'last':-1,'label':None};unreal._smooth_video=V
lib=unreal.get_default_object(unreal.GameplayStatics)
def spawn(cls,loc,rot):
 tr=unreal.Transform(location=loc,rotation=rot);a=lib.call_method('BeginDeferredActorSpawnFromClass',args=(w,cls,tr,unreal.SpawnActorCollisionHandlingMethod.ALWAYS_SPAWN,None,unreal.SpawnActorScaleMethod.MULTIPLY_WITH_ROOT));V['actors'].append(a);return lib.call_method('FinishSpawningActor',args=(a,tr,unreal.SpawnActorScaleMethod.MULTIPLY_WITH_ROOT))
def finish_video(error=None):
 if V['handle'] is not None:unreal.unregister_slate_post_tick_callback(V['handle']);V['handle']=None
 pc.set_view_target_with_blend(p,0.);p.set_actor_location(V['location'],False,False);p.set_actor_rotation(V['rotation'],False);p.set_actor_tick_enabled(V['tick']);b.set_editor_property('global_anim_rate_scale',V['rate'])
 for n,x in V['inputs'].items():p.set_editor_property(n,x)
 for a in reversed(V['actors']):a.destroy_actor()
 settings.set_editor_property('bThrottleCPUWhenNotForeground',V['throttle']);unreal.SystemLibrary.execute_console_command(p,'t.MaxFPS '+str(V['fps']))
 for n,x in V['render'].items():unreal.SystemLibrary.execute_console_command(p,n+' '+str(x))
 (O/'VideoSamples.json').write_text(json.dumps({'error':error,'rows':V['rows']},separators=(',',':')),encoding='utf8')
try:
 settings.set_editor_property('bThrottleCPUWhenNotForeground',False);unreal.SystemLibrary.execute_console_command(p,'t.MaxFPS 60')
 for n in V['render']:unreal.SystemLibrary.execute_console_command(p,n+' 0')
 p.set_actor_tick_enabled(False);p.set_actor_location(unreal.Vector(110,0,0),False,False);p.set_actor_rotation(unreal.Rotator(pitch=0,yaw=0,roll=0),False);b.set_editor_property('global_anim_rate_scale',1.);b.set_anim_instance_class(None);b.set_anim_instance_class(unreal.load_asset(base+'/ABP_Smoothing03_Crouch').generated_class())
 other=spawn(p.get_class(),unreal.Vector(-110,0,0),unreal.Rotator());other.set_actor_tick_enabled(False);b2=other.get_editor_property('body');b2.set_anim_instance_class(unreal.load_asset(base+'/ABP_TorsoReferenceEight_Crouch').generated_class());b2.set_editor_property('global_anim_rate_scale',1.);V['other']=other;V['body2']=b2
 for x,label in [(-110,'A  |  0.2 s'),(110,'B  |  0.3 s')]:
  text=spawn(unreal.TextRenderActor,unreal.Vector(x,0,155),unreal.Rotator(pitch=0,yaw=90,roll=0));tc=text.get_component_by_class(unreal.TextRenderComponent);tc.set_text(label);tc.set_world_size(14.);tc.set_horizontal_alignment(unreal.HorizTextAligment.EHTA_CENTER)
 loc=unreal.Vector(20,650,170);cam=spawn(unreal.CameraActor,loc,unreal.MathLibrary.find_look_at_rotation(loc,unreal.Vector(0,0,80)));cam.get_component_by_class(unreal.CameraComponent).set_field_of_view(48.);pc.set_view_target_with_blend(cam,0.);V['start']=unreal.GameplayStatics.get_time_seconds(w)
 def video_tick(dt):
  try:
   t=unreal.GameplayStatics.get_time_seconds(w)
   if t==V['last']:return
   V['last']=t;e=t-V['start'];yaw=90 if e<3 else 135 if e<4.2 else 0 if e<5.3 else 180 if e<6.4 else 0 if e<7.5 else 90 if e<8.6 else 135 if e<9.8 else 90
   rad=math.radians(yaw);f=math.cos(rad);r=math.sin(rad);m=abs(f)+abs(r)
   for a in [p,other]:a.set_editor_property('PreviewForward',f/m);a.set_editor_property('PreviewRight',r/m)
   V['rows'].append({'elapsed':e,'yaw':yaw,'a_head':b2.get_socket_transform('head',unreal.RelativeTransformSpace.RTS_COMPONENT).translation.z,'b_head':b.get_socket_transform('head',unreal.RelativeTransformSpace.RTS_COMPONENT).translation.z,'a_phase':b2.get_anim_instance().call_method('GetInstanceAssetPlayerTime',args=(0,)),'b_phase':b.get_anim_instance().call_method('GetInstanceAssetPlayerTime',args=(0,))})
   if e>=13.:finish_video()
  except Exception:finish_video(traceback.format_exc())
 V['handle']=unreal.register_slate_post_tick_callback(video_tick)
except Exception:finish_video(traceback.format_exc())
