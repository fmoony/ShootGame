import pathlib,json,math,collections,statistics
O=pathlib.Path(__file__).parent;D=json.loads((O/'DynamicPair.json').read_text());assert D['state']=='Complete',D.get('error');R=D['rows'];G=collections.defaultdict(list)
for i,r in enumerate(R):r['index']=i;G[r['case']].append(r)
def z(r,k,n):return r['poses'][k]['bones'][n]['p'][2]
def met(rs,k,n):
 pairs=[(a,b) for a,b in zip(rs,rs[1:]) if .001<b['t']-a['t']<.05]
 up=max(pairs,key=lambda ab:(z(ab[1],k,n)-z(ab[0],k,n))/(ab[1]['t']-ab[0]['t']));down=min(pairs,key=lambda ab:(z(ab[1],k,n)-z(ab[0],k,n))/(ab[1]['t']-ab[0]['t']));win=[(a,b) for j,a in enumerate(rs) for b in rs[j+1:j+8] if .001<b['t']-a['t']<=.1001];wr=max(win,key=lambda ab:z(ab[1],k,n)-z(ab[0],k,n))
 def row(a,b):return {'indices':[a['index'],b['index']],'dt':b['t']-a['t'],'dz':z(b,k,n)-z(a,k,n),'speed':(z(b,k,n)-z(a,k,n))/(b['t']-a['t'])}
 return {'mean':statistics.mean(z(r,k,n) for r in rs),'min':min(z(r,k,n) for r in rs),'max':max(z(r,k,n) for r in rs),'up':row(*up),'down':row(*down),'rise_100ms':row(*wr)}
cases=[]
for i,c in enumerate(D['cases']):cases.append({'case':c,'metrics':{k:{n:met(G[i],k,n) for n in ['head','spine_05','pelvis','root']} for k in ['baseline','trial']}})
lower=['root','pelvis','thigh_l','thigh_r','calf_l','calf_r','foot_l','foot_r','ball_l','ball_r']
s={'frames':len(R),'cases':len(cases),'lower_max_cm':max(math.dist(r['poses']['baseline']['bones'][n]['p'],r['poses']['trial']['bones'][n]['p']) for r in R for n in lower),'input_difference':max(abs(r['poses']['baseline']['graph'][i]-r['poses']['trial']['graph'][i]) for r in R for i in range(2)),'max_phase_delta':max(r['phase_delta'] for r in R),'actor_z':{k:[min(r['poses'][k]['actor_z'] for r in R),max(r['poses'][k]['actor_z'] for r in R)] for k in ['baseline','trial']},'long_intervals':[{'case':D['cases'][a['case']]['name'],'dt':b['t']-a['t']} for a,b in zip(R,R[1:]) if a['case']==b['case'] and b['t']-a['t']>=.05]}
groups=collections.defaultdict(list)
for c in cases:groups[c['case']['name'].split('_phase')[0]].append(c)
s['groups']={name:{k:{'head_up_cm':max(x['metrics'][k]['head']['up']['speed'] for x in cs)/60.,'head_rise_100ms_cm':max(x['metrics'][k]['head']['rise_100ms']['dz'] for x in cs)} for k in ['baseline','trial']} for name,cs in groups.items()};s['case_metrics']=cases
(O/'PairAnalysis.json').write_text(json.dumps(s,indent=2),encoding='utf8')
print(json.dumps({k:s[k] for k in ['frames','cases','lower_max_cm','input_difference','actor_z','long_intervals']},indent=2))
for n in ['F_B','B_F','R_BR','BR_R','B_BR','BR_B','B_BL','BL_B','BL_L','L_BL','FL_L','L_FL']:
 if n in s['groups']:print(n,s['groups'][n])
