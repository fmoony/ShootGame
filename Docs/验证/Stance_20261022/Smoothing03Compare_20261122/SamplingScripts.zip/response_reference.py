import unreal,json,pathlib,math,traceback,time
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/Smoothing03Compare_20261122_01");base='/Game/Experiments/Stance_20261022'
try:
 paths={0:'AS_RootLockSource_Forward',45:'AS_BlendBaked_ForwardRight',90:'AS_RootLockSource_Right',135:'AS_BackRight_TorsoReference',180:'AS_Back_TorsoReference',-135:'AS_BackLeft_TorsoReference',-90:'AS_RootLockSource_Left',-45:'AS_OWBaked_FrontLeft'};mesh=unreal.load_asset('/Game/Characters/Mannequins/Meshes/SKM_Manny_Simple');opt=unreal.AnimPoseEvaluationOptions(evaluation_type=unreal.AnimDataEvalType.COMPRESSED,should_retarget=True,extract_root_motion=False,incorporate_root_motion_into_pose=True,optional_skeletal_mesh=mesh);bones=['root','pelvis','spine_05','head','foot_l','foot_r'];results={};assets={n:unreal.load_asset(base+'/'+v) for n,v in paths.items()}
 for filename in ['DynamicPair','FocusPair']:
  data=json.loads((O/(filename+'.json')).read_text());assert data['state']=='Complete';rows=[]
  for i,r in enumerate(data['rows']):
   c=data['cases'][r['case']];phase=r['poses']['baseline']['phase'];pose=unreal.AnimPoseExtensions.get_anim_pose_at_time(assets[int(c['to'])],phase,opt);expected={n:unreal.AnimPoseExtensions.get_bone_pose(pose,n,unreal.AnimPoseSpaces.WORLD).translation.to_tuple() for n in bones};errors={k:{n:math.dist(v['bones'][n]['p'],expected[n]) for n in bones} for k,v in r['poses'].items()};rows.append({'index':i,'case':r['case'],'t':r['t'],'elapsed':r['elapsed'],'phase':phase,'errors':errors})
  results[filename]=rows
 (O/'PoseResponse.json').write_text(json.dumps({'state':'Complete','bones':bones,'threshold_cm':1.,'data':results},separators=(',',':')),encoding='utf8')
except Exception:(O/'ResponseError.txt').write_text(traceback.format_exc(),encoding='utf8')
