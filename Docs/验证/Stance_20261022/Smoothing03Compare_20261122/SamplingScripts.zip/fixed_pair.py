import unreal,json,pathlib,traceback,time,math
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/Smoothing03Compare_20261122_01");base='/Game/Experiments/Stance_20261022';pairs=[('R_BR',(0,1),(-.5,.5),'AS_RootLockSource_Right','AS_BackRight_TorsoReference'),('F_B',(1,0),(-1,0),'AS_RootLockSource_Forward','AS_Back_TorsoReference'),('B_F',(-1,0),(1,0),'AS_Back_TorsoReference','AS_RootLockSource_Forward')];cases=[{'name':n,'from':list(a),'to':list(b),'source':base+'/'+s,'target':base+'/'+t,'phase':ph} for n,a,b,s,t in pairs for ph in [0.,.25,.5,.75]]
D={'handle':None,'case':0,'rows':[],'endpoints':[],'last':-1,'start':time.monotonic()};unreal._smooth_fixed=D;names=['root','pelvis','spine_01','spine_05','neck_02','head','clavicle_l','clavicle_r','hand_l','hand_r','foot_l','foot_r','ball_l','ball_r']
def end_fixed(state,error=None):
 if D['handle'] is not None:unreal.unregister_slate_post_tick_callback(D['handle']);D['handle']=None
 if 'secondary' in D:D['secondary'].destroy_actor();D.pop('secondary')
 if 'p' in D:
  D['body'].set_anim_instance_class(D['oldclass']);D['body'].set_editor_property('global_anim_rate_scale',D['rate']);D['p'].set_actor_tick_enabled(D['tick']);D['settings'].set_editor_property('bThrottleCPUWhenNotForeground',D['throttle']);unreal.SystemLibrary.execute_console_command(D['p'],'t.MaxFPS '+str(D['fps']))
 (O/'FixedPair.json').write_text(json.dumps({'state':state,'error':error,'cases':cases,'endpoints':D['endpoints'],'rows':D['rows']},separators=(',',':')),encoding='utf8');(O/'FixedStatus.json').write_text(json.dumps({'state':state,'error':error,'cases':D['case'],'frames':len(D['rows'])}),encoding='utf8')
def set_case(t):
 c=cases[D['case']]
 for b in [D['body'],D['body2']]:b.get_anim_instance().set_blend_space_position(unreal.Vector(*c['from'],0.));b.get_anim_instance().set_position(c['phase'],False)
 ep={'case':D['case']}
 for role in ['source','target']:
  pose=unreal.AnimPoseExtensions.get_anim_pose_at_time(unreal.load_asset(c[role]),c['phase'],D['opt']);ep[role]={n:list(unreal.AnimPoseExtensions.get_bone_pose(pose,n,unreal.AnimPoseSpaces.WORLD).translation.to_tuple()) for n in names}
 D['endpoints'].append(ep);D['mode']='warm';D['time']=t
 (O/'FixedStatus.json').write_text(json.dumps({'state':'Running','case':D['case'],'total':len(cases),'frames':len(D['rows'])}),encoding='utf8')
def record(t):
 r={'case':D['case'],'t':t,'elapsed':t-D['time'],'poses':{}}
 for label,b in [('baseline',D['body2']),('trial',D['body'])]:
  bones={}
  for n in names:
   tr=b.get_socket_transform(n,unreal.RelativeTransformSpace.RTS_COMPONENT);bones[n]={'p':list(tr.translation.to_tuple()),'q':list(tr.rotation.to_tuple())}
  r['poses'][label]={'phase':b.get_position(),'bones':bones}
  assert abs(b.get_position()-cases[D['case']]['phase'])<1e-6
 return r
def tick_fixed(dt):
 try:
  t=unreal.GameplayStatics.get_time_seconds(D['world'])
  if t==D['last']:return
  D['last']=t
  if D['mode']=='warm':
   if t-D['time']<1.3:return
   D['mode']='run';D['time']=t;D['rows'].append(record(t));c=cases[D['case']]
   for b in [D['body'],D['body2']]:b.get_anim_instance().set_blend_space_position(unreal.Vector(*c['to'],0.))
   return
  D['rows'].append(record(t))
  if t-D['time']>=.9:
   D['case']+=1
   if D['case']>=len(cases):end_fixed('Complete');return
   set_case(t)
  if time.monotonic()-D['start']>90:end_fixed('Timeout')
 except Exception:end_fixed('Failed',traceback.format_exc())
try:
 w=unreal.EditorLevelLibrary.get_game_world();p=unreal.GameplayStatics.get_player_pawn(w,0);b=p.get_editor_property('body');settings=unreal.load_object(None,'/Script/UnrealEd.Default__EditorPerformanceSettings');D.update(world=w,p=p,body=b,oldclass=b.get_anim_instance().get_class(),rate=b.get_editor_property('global_anim_rate_scale'),tick=p.is_actor_tick_enabled(),settings=settings,throttle=settings.get_editor_property('bThrottleCPUWhenNotForeground'),fps=unreal.SystemLibrary.get_console_variable_float_value('t.MaxFPS'))
 settings.set_editor_property('bThrottleCPUWhenNotForeground',False);unreal.SystemLibrary.execute_console_command(p,'t.MaxFPS 60');p.set_actor_tick_enabled(False);tr=p.get_actor_transform();tr.translation=unreal.Vector(0,400,0);lib=unreal.get_default_object(unreal.GameplayStatics);p2=lib.call_method('BeginDeferredActorSpawnFromClass',args=(w,p.get_class(),tr,unreal.SpawnActorCollisionHandlingMethod.ALWAYS_SPAWN,None,unreal.SpawnActorScaleMethod.MULTIPLY_WITH_ROOT));D['secondary']=p2;p2=lib.call_method('FinishSpawningActor',args=(p2,tr,unreal.SpawnActorScaleMethod.MULTIPLY_WITH_ROOT));p2.set_actor_tick_enabled(False);p2.set_actor_hidden_in_game(True);b2=p2.get_editor_property('body');D['body2']=b2;b2.set_editor_property('visibility_based_anim_tick_option',unreal.VisibilityBasedAnimTickOption.ALWAYS_TICK_POSE_AND_REFRESH_BONES)
 for body,name in [(b,'BS_Smoothing03_Crouch'),(b2,'BS_TorsoReferenceEight_Crouch')]:
  body.set_editor_property('global_anim_rate_scale',1.);body.play_animation(unreal.load_asset(base+'/'+name),False);ai=body.get_anim_instance();ai.set_play_rate(0.);ai.set_playing(True);ai.set_looping(False)
 D['opt']=unreal.AnimPoseEvaluationOptions(evaluation_type=unreal.AnimDataEvalType.COMPRESSED,should_retarget=True,extract_root_motion=False,incorporate_root_motion_into_pose=True,optional_skeletal_mesh=b.get_skeletal_mesh_asset());set_case(unreal.GameplayStatics.get_time_seconds(w));D['handle']=unreal.register_slate_post_tick_callback(tick_fixed)
except Exception:end_fixed('SetupFailed',traceback.format_exc())
