import unreal,json,pathlib,traceback
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01")
try:
 base='/Game/Experiments/Stance_20261022';reg=unreal.AssetRegistryHelpers.get_asset_registry()
 opts=unreal.AssetRegistryDependencyOptions(include_soft_package_references=True,include_hard_package_references=True,include_searchable_names=True,include_soft_management_references=True,include_hard_management_references=True)
 assets=reg.get_assets_by_path(base,recursive=True,include_only_on_disk_assets=True)
 rows={}
 for a in assets:
  p=str(a.package_name);rows[p]={'class':str(a.asset_class_path.asset_name),'deps':sorted(str(x) for x in reg.get_dependencies(p,opts)),'refs':sorted(str(x) for x in reg.get_referencers(p,opts))}
 roots=[base+'/L_Smoothing03_Crouch']
 seen=set();todo=list(roots);parents={}
 while todo:
  p=todo.pop()
  if p in seen:continue
  seen.add(p)
  if not p.startswith('/Game/'):continue
  ds=rows[p]['deps'] if p in rows else [str(x) for x in reg.get_dependencies(p,opts)]
  for d in ds:
   parents.setdefault(d,p)
   if d.startswith('/Game/') and d not in seen:todo.append(d)
 keep=sorted(p for p in seen if p.startswith(base+'/'))
 candidates=sorted(p for p in rows if p not in keep)
 boundary={p:[x for x in rows[p]['refs'] if x not in candidates] for p in candidates}
 boundary={p:v for p,v in boundary.items() if v}
 d={'base':base,'world':unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world().get_path_name(),'roots':roots,'assets':rows,'keep':keep,'candidates':candidates,'boundary':boundary,'parents':parents,'loading':reg.is_loading_assets(),'dirty_content':[p.get_path_name() for p in unreal.EditorLoadingAndSavingUtils.get_dirty_content_packages()],'dirty_maps':[p.get_path_name() for p in unreal.EditorLoadingAndSavingUtils.get_dirty_map_packages()],'delete_loaded_assets_doc':unreal.EditorAssetLibrary.delete_loaded_assets.__doc__}
 assert not d['loading'] and not boundary

 assert not d['dirty_content'] and not d['dirty_maps']
 (O/'Audit.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
except Exception:(O/'AuditError.txt').write_text(traceback.format_exc(),encoding='utf8')
