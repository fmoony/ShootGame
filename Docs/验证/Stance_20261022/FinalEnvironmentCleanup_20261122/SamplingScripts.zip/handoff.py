import unreal,json,pathlib,traceback
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01")
HF={'handle':None}
def handoff_tick(dt):
 try:
  w=unreal.EditorLevelLibrary.get_game_world();p=unreal.GameplayStatics.get_player_pawn(w,0);b=p.get_editor_property('body');ai=b.get_anim_instance();pc=unreal.GameplayStatics.get_player_controller(w,0);gm=unreal.GameplayStatics.get_game_mode(w)
  lib=unreal.load_class(None,'/Script/UMG.WidgetBlueprintLibrary');unreal.get_default_object(lib).call_method('SetInputMode_GameOnly',args=(pc,False))
  keys={}
  for n in 'WASD':
   k=unreal.Key();k.import_text(n);keys[n]=pc.is_input_key_down(k)
  state={'world':w.get_path_name(),'pawn_tick':p.is_actor_tick_enabled(),'anim_class':ai.get_class().get_path_name(),'configured_anim':gm.get_editor_property('preview_anim_class').get_path_name(),'game_mode':gm.get_class().get_path_name(),'actor':list(p.get_actor_location().to_tuple()),'inputs':[p.get_editor_property('PreviewForward'),p.get_editor_property('PreviewRight')],'graph':[ai.get_editor_property('Forward'),ai.get_editor_property('Right')],'keys':keys,'rate':b.get_editor_property('global_anim_rate_scale'),'fps':unreal.SystemLibrary.get_console_variable_float_value('t.MaxFPS'),'render':{k:unreal.SystemLibrary.get_console_variable_int_value(k) for k in ['r.MotionBlurQuality','r.AntiAliasingMethod']},'throttle':unreal.load_object(None,'/Script/UnrealEd.Default__EditorPerformanceSettings').get_editor_property('bThrottleCPUWhenNotForeground'),'dirty_content':[x.get_path_name() for x in unreal.EditorLoadingAndSavingUtils.get_dirty_content_packages()],'dirty_maps':[x.get_path_name() for x in unreal.EditorLoadingAndSavingUtils.get_dirty_map_packages()]}
  assert state['pawn_tick'] and state['anim_class']==state['configured_anim'] and state['anim_class'].endswith('/ABP_Smoothing03_Crouch.ABP_Smoothing03_Crouch_C')
  assert not any(keys.values()) and not state['dirty_content'] and not state['dirty_maps']
  (O/'Handoff.json').write_text(json.dumps(state,indent=2),encoding='utf8')
 except Exception:(O/'HandoffError.txt').write_text(traceback.format_exc(),encoding='utf8')
 finally:unreal.unregister_slate_post_tick_callback(HF['handle'])
HF['handle']=unreal.register_slate_post_tick_callback(handoff_tick)
