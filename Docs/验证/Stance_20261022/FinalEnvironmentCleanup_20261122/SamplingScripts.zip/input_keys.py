import ctypes as C,time,json,pathlib
from ctypes import wintypes as W
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01")
U=C.windll.user32;U.GetForegroundWindow.restype=W.HWND;U.GetWindowThreadProcessId.argtypes=[W.HWND,C.POINTER(W.DWORD)];U.PostMessageW.argtypes=[W.HWND,W.UINT,W.WPARAM,W.LPARAM];U.SetForegroundWindow.argtypes=[W.HWND]
found=[];CB=C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
@CB
def cb(h,_):
 pid=W.DWORD();U.GetWindowThreadProcessId(h,C.byref(pid));title=C.create_unicode_buffer(512);U.GetWindowTextW(h,title,512)
 if pid.value==24788 and title.value.startswith('ShootGame Preview [NetMode:'):found.append(int(h))
 return True
U.EnumWindows(cb,0);held=set();events=[];result={'method':'Targeted Win32 messages to unique verified UE PID 24788 preview HWND','windows':found}
def keys(target,seconds,label):
 global held
 assert U.IsWindow(found[0])
 for k in held-set(target):assert U.PostMessageW(found[0],0x101,ord(k),0xC0000001|(U.MapVirtualKeyW(ord(k),0)<<16))
 for k in set(target)-held:assert U.PostMessageW(found[0],0x100,ord(k),1|(U.MapVirtualKeyW(ord(k),0)<<16))
 held=set(target);start=time.monotonic();events.append({'label':label,'keys':target,'seconds':seconds})
 while time.monotonic()-start<seconds:time.sleep(.015)
try:
 assert len(found)==1,'expected unique project preview window'
 U.SetForegroundWindow(found[0]);time.sleep(.3)
 for label,target in [('F','W'),('FR','WD'),('R','D'),('BR','SD'),('B','S'),('BL','SA'),('L','A'),('FL','WA')]:
  keys(target,.9,label);keys('',.25,label+'_stop')
 keys('',.6,'FinalStop');result['state']='Complete'
except Exception as e:result.update(state='Failed',error=str(e))
finally:
 for k in held:U.PostMessageW(found[0],0x101,ord(k),0xC0000001|(U.MapVirtualKeyW(ord(k),0)<<16))
 result['events']=events;(O/'InputDone.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({'state':result.get('state'),'error':result.get('error'),'events':len(events)}))
