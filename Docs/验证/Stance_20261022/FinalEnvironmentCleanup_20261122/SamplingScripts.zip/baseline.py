import unreal,pathlib,json,traceback
from editor_toolset.toolsets.blueprint import BlueprintTools as BT
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01");base='/Game/Experiments/Stance_20261022'
try:
 assert not unreal.EditorLevelLibrary.get_game_world()
 bp=unreal.load_asset(base+'/ABP_Smoothing03_Crouch');graph=unreal.BlueprintGraphEditor.get_graph_editor(BT.get_graph(bp,'AnimGraph'))
 node=next(x for x in graph.list_all_nodes() if isinstance(x,unreal.AnimGraphNode_BlendSpacePlayer));bs=unreal.load_asset(base+'/BS_Smoothing03_Crouch')
 gm=unreal.load_asset(base+'/BP_Smoothing03GameMode');cdo=unreal.get_default_object(gm.generated_class());native=unreal.get_default_object(unreal.load_class(None,'/Script/ShootGameEditor.ShooterFourDirectionPreviewGameMode'))
 result={'anim_node':node.get_editor_property('node').export_text(),'node_count':len(graph.list_all_nodes()),'smoothing':[x.get_editor_property('interpolation_time') for x in bs.get_editor_property('interpolation_param')],'samples':[x.export_text() for x in bs.get_editor_property('sample_data')],'game_mode_anim':str(cdo.get_editor_property('preview_anim_class')),'native_default_anim':str(native.get_editor_property('preview_anim_class')),'quit_doc':str(getattr(unreal.SystemLibrary,'quit_editor',None)),'close_editors_doc':unreal.AssetEditorSubsystem.close_all_editors_for_asset.__doc__}
 (O/'FinalBaseline.json').write_text(json.dumps(result,indent=2),encoding='utf8')
except Exception:(O/'FinalBaselineError.txt').write_text(traceback.format_exc())
