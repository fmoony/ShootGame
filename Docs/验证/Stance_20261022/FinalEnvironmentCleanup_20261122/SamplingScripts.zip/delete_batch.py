import unreal,json,pathlib,traceback
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01")
def status(state,**kw):(O/'DeleteStatus.json').write_text(json.dumps({'state':state,**kw},ensure_ascii=False,indent=2),encoding='utf8')
def delete_batch(dt):
 unreal.unregister_slate_post_tick_callback(delete_handle)
 try:
  audit=json.loads((O/'Audit.json').read_text());backup=json.loads((O/'Backup.json').read_text())
  paths=audit['candidates'];keep=set(audit['keep'])
  assert backup['verified'] and len(paths)==backup['count']==21
  assert set(paths)=={e['package'] for e in backup['files']}
  assert all(p.startswith('/Game/Experiments/Stance_20261022/') and p not in keep for p in paths)
  assert not unreal.EditorLoadingAndSavingUtils.get_dirty_content_packages()
  assert not unreal.EditorLoadingAndSavingUtils.get_dirty_map_packages()
  reg=unreal.AssetRegistryHelpers.get_asset_registry()
  opts=unreal.AssetRegistryDependencyOptions(include_soft_package_references=True,include_hard_package_references=True,include_searchable_names=True,include_soft_management_references=True,include_hard_management_references=True)
  allowed=set(paths)
  for p in paths:
   refs=[str(x) for x in reg.get_referencers(p,opts)]
   assert all(x in allowed for x in refs),(p,refs)
  objects=[]
  for i,p in enumerate(paths):
   asset=unreal.EditorAssetLibrary.load_asset(p);assert asset,p
   objects.append(asset)
   if i%20==0:status('LoadingCandidates',loaded=i+1,total=len(paths))
  status('DeletingNativeBatch',count=len(objects))
  ok=unreal.EditorAssetLibrary.delete_loaded_assets(objects)
  objects.clear()
  remaining=sorted(str(a.package_name) for a in reg.get_assets_by_path(audit['base'],recursive=True,include_only_on_disk_assets=True))
  result={'native_result':ok,'expected_deleted':paths,'remaining':remaining,'remaining_deleted_candidates':sorted(set(remaining)&set(paths)),'missing_kept':sorted(keep-set(remaining)),'dirty_content':[p.get_path_name() for p in unreal.EditorLoadingAndSavingUtils.get_dirty_content_packages()],'dirty_maps':[p.get_path_name() for p in unreal.EditorLoadingAndSavingUtils.get_dirty_map_packages()]}
  (O/'DeleteResult.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
  assert ok and not result['remaining_deleted_candidates'] and not result['missing_kept']
  assert len(remaining)==14
  status('Complete',deleted=21,remaining=len(remaining))
 except Exception:status('Failed',error=traceback.format_exc())
status('Scheduled')
delete_handle=unreal.register_slate_post_tick_callback(delete_batch)
