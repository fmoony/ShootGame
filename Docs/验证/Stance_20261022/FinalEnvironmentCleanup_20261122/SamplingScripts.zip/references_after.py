import unreal,json,pathlib,traceback
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01")
try:
 audit=json.loads((O/'Audit.json').read_text());deleted=set(audit['candidates']);keep=set(audit['keep'])
 reg=unreal.AssetRegistryHelpers.get_asset_registry()
 opts=unreal.AssetRegistryDependencyOptions(include_soft_package_references=True,include_hard_package_references=True,include_searchable_names=True,include_soft_management_references=True,include_hard_management_references=True)
 current=reg.get_assets_by_path(audit['base'],recursive=True,include_only_on_disk_assets=True)
 actual={str(a.package_name) for a in current}
 game_assets=reg.get_assets_by_path('/Game',recursive=True,include_only_on_disk_assets=True)
 dangling={};kept_missing={}
 for asset in game_assets:
  p=str(asset.package_name);deps=[str(x) for x in reg.get_dependencies(p,opts)]
  bad=sorted(set(deps)&deleted)
  if bad:dangling[p]=bad
  if p in keep:
   missed=[d for d in deps if d.startswith('/Game/') and not reg.get_assets_by_package_name(d,include_only_on_disk_assets=True)]
   if missed:kept_missing[p]=missed
 # Remove only empty experimental subfolders through the UE asset system.
 folders=sorted({p.rsplit('/',1)[0] for p in deleted if p.rsplit('/',1)[0]!=audit['base']},key=lambda x:x.count('/'),reverse=True)
 removed_folders=[]
 for folder in folders:
  if unreal.EditorAssetLibrary.does_directory_exist(folder) and not unreal.EditorAssetLibrary.list_assets(folder,recursive=True,include_folder=False):
   assert folder.startswith(audit['base']+'/')
   ok=unreal.EditorAssetLibrary.delete_directory(folder)
   removed_folders.append({'path':folder,'success':ok})
 result={'remaining':sorted(actual),'removed_count':len(deleted),'missing_kept':sorted(keep-actual),'unexpected_assets':sorted(actual-keep),'checked_game_assets':len(game_assets),'dangling_to_removed':dangling,'kept_missing_game_dependencies':kept_missing,'redirectors':[str(a.package_name) for a in current if str(a.asset_class_path.asset_name)=='ObjectRedirector'],'empty_folders':removed_folders,'dirty_content':[p.get_path_name() for p in unreal.EditorLoadingAndSavingUtils.get_dirty_content_packages()],'dirty_maps':[p.get_path_name() for p in unreal.EditorLoadingAndSavingUtils.get_dirty_map_packages()]}
 assert not dangling and not kept_missing and actual==keep
 assert not result['dirty_content'] and not result['dirty_maps']
 (O/'ReferencesAfter.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
except Exception:(O/'ReferencesAfterError.txt').write_text(traceback.format_exc(),encoding='utf8')
