import unreal,json,pathlib,time,traceback
O=pathlib.Path(r"D:/UE_Projects/_worktrees/ShootGame_UE58/Saved/StanceFinalCleanup_20261122_01")
KM={'handle':None,'rows':[],'last':-1,'start':time.monotonic()}
def end_keys(state,error=None):
 unreal.unregister_slate_post_tick_callback(KM['handle'])
 if 'p' in KM:
  KM['settings'].set_editor_property('bThrottleCPUWhenNotForeground',KM['throttle']);unreal.SystemLibrary.execute_console_command(KM['p'],'t.MaxFPS '+str(KM['fps']))
 (O/'KeyboardFrames.json').write_text(json.dumps({'state':state,'error':error,'rows':KM['rows']},separators=(',',':')),encoding='utf8')
def keys_tick(dt):
 try:
  w=unreal.EditorLevelLibrary.get_game_world();p=unreal.GameplayStatics.get_player_pawn(w,0);b=p.get_editor_property('body');pc=unreal.GameplayStatics.get_player_controller(w,0)
  if 'p' not in KM:
   assert p.is_actor_tick_enabled() and b.get_anim_instance().get_class().get_name()=='ABP_Smoothing03_Crouch_C'
   settings=unreal.load_object(None,'/Script/UnrealEd.Default__EditorPerformanceSettings')
   KM.update(p=p,settings=settings,throttle=settings.get_editor_property('bThrottleCPUWhenNotForeground'),fps=unreal.SystemLibrary.get_console_variable_float_value('t.MaxFPS'))
   settings.set_editor_property('bThrottleCPUWhenNotForeground',False);unreal.SystemLibrary.execute_console_command(p,'t.MaxFPS 60')
   lib=unreal.load_class(None,'/Script/UMG.WidgetBlueprintLibrary');unreal.get_default_object(lib).call_method('SetInputMode_GameOnly',args=(pc,False))
  t=unreal.GameplayStatics.get_time_seconds(w)
  if t==KM['last']:return
  KM['last']=t;keys={}
  for n in 'WASD':
   k=unreal.Key();k.import_text(n);keys[n]=pc.is_input_key_down(k)
  ai=b.get_anim_instance();poses={}
  for n in ['root','pelvis','spine_05','head','foot_l','foot_r','calf_l','calf_r']:
   tr=b.get_socket_transform(n,unreal.RelativeTransformSpace.RTS_COMPONENT);poses[n]={'p':list(tr.translation.to_tuple()),'q':list(tr.rotation.to_tuple())}
  KM['rows'].append({'t':t,'keys':keys,'location':list(p.get_actor_location().to_tuple()),'input':[p.get_editor_property('PreviewForward'),p.get_editor_property('PreviewRight')],'graph':[ai.get_editor_property('Forward'),ai.get_editor_property('Right')],'rate':b.get_editor_property('global_anim_rate_scale'),'class':ai.get_class().get_path_name(),'bones':poses})
  if (O/'InputDone.json').exists():end_keys('Complete')
  elif time.monotonic()-KM['start']>35:end_keys('Timeout')
 except Exception:end_keys('Failed',traceback.format_exc())
KM['handle']=unreal.register_slate_post_tick_callback(keys_tick)
